No importa lo que se escriba en el alert.
Doge siempre es un buen perro