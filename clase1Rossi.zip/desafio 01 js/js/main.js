let pregunta = prompt("¿es doge un buen perro?");

//obviedad

alert('gracias por confirmar que doge es un buen perro.')